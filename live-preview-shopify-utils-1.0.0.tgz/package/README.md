# Live Preview Shopify Utils

A utility package for Shopify live preview functionality that provides a singleton instance for managing Shopify live preview features and GitHub integration.

## Installation

```bash
npm install live-preview-shopify-utils
```

## Usage

### Basic Setup

```typescript
import { LivePreviewShopify, LivePreviewConfig } from 'live-preview-shopify-utils';
import express from 'express';

const app = express();

// Initialize with configuration
const config: LivePreviewConfig = {
  apiVersion: '2024-01',
  expressApp: app
};

// Get the singleton instance
const livePreview = LivePreviewShopify.getInstance(config);

// The same instance will be returned everywhere in your application
const sameInstance = LivePreviewShopify.getInstance();
// sameInstance === livePreview // true
```

### GitHub Integration

The package includes GitHub integration for fetching repository content:

```typescript
import { LivePreviewShopify, GitHubConfig } from 'live-preview-shopify-utils';

// Configure GitHub
const githubConfig: GitHubConfig = {
  auth: 'your-github-token',
  owner: 'your-username',
  repo: 'your-repo'
};

// Method 1: Configure during initialization
const config = {
  apiVersion: '2024-01',
  expressApp: app,
  githubConfig
};
const livePreview = LivePreviewShopify.getInstance(config);

// Method 2: Configure after initialization
livePreview.configureGitHub(githubConfig);

// Fetch repository content
const content = await livePreview.fetchRepositoryContent('path/to/file', 'main');
```

## Features

- Singleton pattern ensures consistent state across your application
- TypeScript support with full type definitions
- Express.js integration
- GitHub repository content fetching
- Liquid template engine integration
- Comprehensive test coverage

## Development

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Make your changes in the `src` directory
4. Build the package:
   ```bash
   npm run build
   ```
5. Run tests:
   ```bash
   npm test
   ```

## Scripts

- `npm run build` - Builds the package using TypeScript
- `npm test` - Runs the test suite
- `npm run lint` - Lints the code using ESLint
- `npm run format` - Formats the code using Prettier

## API Reference

### LivePreviewShopify

The main class that implements the singleton pattern.

#### Methods

- `getInstance(config?: LivePreviewConfig)`: Get the singleton instance
- `configureGitHub(config: GitHubConfig)`: Configure GitHub integration
- `fetchRepositoryContent(path?: string, branch?: string)`: Fetch repository content
- `getLiquidEngine()`: Get the Liquid template engine instance
- `processRequest(req: IncomingMessage)`: Process incoming preview requests

### Interfaces

#### LivePreviewConfig
```typescript
interface LivePreviewConfig {
  apiVersion: string;
  expressApp: Application;
  githubConfig?: GitHubConfig;
}
```

#### GitHubConfig
```typescript
interface GitHubConfig {
  auth: string;
  owner: string;
  repo: string;
  branch?: string;
  path?: string;
}
```

## License

MIT 